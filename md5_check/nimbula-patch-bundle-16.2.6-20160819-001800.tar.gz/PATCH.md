# Patch Instructions, List out the tickets
https://jira.oraclecorp.com/jira/browse/OCC-27805
